using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camara3pers : MonoBehaviour
{
    //Variables para cambio de cámmara.
    public Transform player; // El objeto del jugador.
    public float distanciaestatica = 13.0f; // Distancia en el modo estático.
    public float distanciatercerapersona = 7.0f; // Distancia en el modo de tercera persona.
    public float altura = 3.0f; // Altura con respecto al jugador.
    public float velocidadsuave = 5.0f; // Velocidad de suavizado.

    private Vector3 staticPosition;
    private Vector3 tercerapersonaPosition;
    private bool terceraPersona = false; // Estado de la cámara (estático o tercera persona).

    void Start()
    {
        staticPosition = new Vector3(0, altura, -distanciaestatica);
        tercerapersonaPosition = new Vector3(0, altura, -distanciatercerapersona);
    }

    void Update()
    {
        // Cambio de modo cuando el jugador presiona "Z" o "C".
        if (Input.GetKeyDown(KeyCode.Z))
        {
            terceraPersona = false;
        }
        else if (Input.GetKeyDown(KeyCode.C))
        {
            terceraPersona = true;
        }

        // Calcula la posición deseada según el modo actual.
        Vector3 desiredPosition = terceraPersona ? player.position + tercerapersonaPosition : player.position + staticPosition;

        // Realiza la transición suave.
        Vector3 newPosition = Vector3.MoveTowards(transform.position, desiredPosition, velocidadsuave * Time.deltaTime);
        transform.position = newPosition;

        // Orienta la cámara hacia el jugador.
        transform.LookAt(player);
    }
}
