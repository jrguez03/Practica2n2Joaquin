using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coleccionables : MonoBehaviour
{
    //Rotacion del coleccionable.
    public float rotationSpeed = 100.0f;

    //Partículas
    public ParticleSystem collectParticles; 

    //Recolect
    private GameManager gameManager;

    void Start()
    {
        gameManager = GameObject.FindWithTag("GameManager").GetComponent<GameManager>();
        collectParticles.Stop(); // Las partículas están desactivadas al inicio.
    }

    // Update is called once per frame
    void Update()
    {
        // Rotar el objeto en el eje Y
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
    }

     private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            gameManager.CollectibleCollected();
            Collect(); // Llama a la función Collect.
        }
    }
    void Collect()
    {
        collectParticles.Play(); // Activa las partículas al recoger el objeto.
        collectParticles.transform.position = transform.position; // Hace que las partículas aparezcan en donde se cumpla esta función.
    }
}
