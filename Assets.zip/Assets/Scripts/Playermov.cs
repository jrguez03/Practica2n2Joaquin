using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playermov : MonoBehaviour
{
    //Variables para el movimiento.
    public float movimientoejeX;
    public float movimientoejeY;
    public float movimientoejeZ;

    public float velocidadmovimiento = 1.5f;

    //Variables salto.
    private Rigidbody rb;
    bool jumping = false;
    public float jumpForce = 5.0f;

    //Variables Audio Coleccionable
    private AudioSource audioSource;

    //Pantalla de derrota.
    public GameObject pantalladerrota;

    //Variables de plataforma.
    public Vector3 targetScale = new Vector3(0f, 0.45f, 0f); // Escala deseada
    public float scaleSpeed = 0.04f; // Velocidad de cambio de escala
    private bool isScaling = false; // Variable para verificar si se está realizando una transición de escala
    private float scaleProgress = 0.0f; // Progreso de la escala
    private GameObject scalingPlatform;
    private Material originalMaterial; // El material original de la plataforma

    //Variables antigravedad.
    private bool isInsideAntigravity = false;
    private Rigidbody antigravityRigidbody;
    private Vector3 antigravityInitialPosition;
    private bool canExitAntigravity = false; // Para controlar si el jugador puede salir del área antigravedad

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        movimientoejeZ = Input.GetAxis("Horizontal") * Time.deltaTime * velocidadmovimiento;
        movimientoejeX = - Input.GetAxis("Vertical") * Time.deltaTime * velocidadmovimiento;
        transform.Translate(movimientoejeX, movimientoejeY, movimientoejeZ);

        if(Input.GetButtonDown("Jump") && !jumping) // La "!" sirve igual que poner "== false".
        {
            jumping = true;
            rb.AddForce(rb.velocity.x, jumpForce, rb.velocity.z, ForceMode.Impulse);
        }

        if (transform.position.y < -10)
        {
            // El jugador ha caído por debajo de -10 en el eje Y, muestra la pantalla de derrota.
            PantallaDerrota();
            Time.timeScale = 0; // Congela el juego.
        }

        if (isScaling)
        {
            if (scaleProgress <= 0.06f)
            {
                scaleProgress += Time.deltaTime * scaleSpeed;
                scalingPlatform.transform.localScale = Vector3.Lerp(scalingPlatform.transform.localScale, targetScale, scaleProgress);
                // Cambia el color del material a rojo
                scalingPlatform.GetComponent<Renderer>().material.color = Color.red;
            }
            else if (scaleProgress > 0.0f)
            {
                isScaling = false;
                scaleProgress = 0.0f;
                Debug.Log("Scale completed, resetting scaleProgress.");
            }
        }

        if (isInsideAntigravity && Input.GetKeyDown(KeyCode.E) && canExitAntigravity)
        {
            // El jugador pulsa "E" para salir del área antigravedad.
            rb.useGravity = true;
            isInsideAntigravity = false;
            antigravityRigidbody.position = antigravityInitialPosition;
            canExitAntigravity = false; // Evita que el jugador salga repetidamente al presionar "E".
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Colect")) //Verifica si el jugador entra en contacto con el colleccionable.
        {
            Destroy(other.gameObject); //Destruye el coleccionable.
            // Reproduce el sonido cuando se destruye el coleccionable.
            if (audioSource != null && audioSource.clip != null)
            {
                audioSource.Play();
            }
        }

        if(other.CompareTag("Antigravedad")) //Verifica si el jugador entra dentro del área sin gravedad.
        {
            isInsideAntigravity = true;
            antigravityRigidbody = other.GetComponent<Rigidbody>();
            antigravityInitialPosition = antigravityRigidbody.position;
            rb.useGravity = false;
            rb.velocity = Vector3.zero;
            canExitAntigravity = true; // Permite que el jugador salga del área antigravedad.
        }
    }

    private void OnTriggerExit(Collider other) //Verifica si el jugador está fuera del área sin gravedad.
    {
        if(other.CompareTag("Antigravedad"))
        {
            isInsideAntigravity = false;
            rb.useGravity = true;
        }
    }

    private void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.CompareTag("Suelo") || other.gameObject.CompareTag("Platform"))
        {
            jumping = false;
        }

        if(other.gameObject.CompareTag("Platform"))
        {
            isScaling = true;
            scalingPlatform = other.gameObject;
        }
    }

    private void PantallaDerrota()
    {
        pantalladerrota.SetActive(true); // Activa el objeto de fin de juego.
    }

    private void FixedUpdate()
    {
        if (isInsideAntigravity && antigravityRigidbody != null)
        {
            // Mueve el jugador al centro del objeto antigravedad
            Vector3 centerPosition = antigravityRigidbody.position;
            rb.MovePosition(centerPosition);

            // Mueve el objeto antigravedad (suponiendo que sea un Rigidbody)
            float horizontalInput = Input.GetAxis("Horizontal");
            float verticalInput = Input.GetAxis("Vertical");
            Vector3 movement = new Vector3(horizontalInput, 0, verticalInput) * velocidadmovimiento * Time.deltaTime;
            antigravityRigidbody.MovePosition(antigravityRigidbody.position + movement);
        }
    }
}
