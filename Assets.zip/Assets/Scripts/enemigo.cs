using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class enemigo : MonoBehaviour
{
    //Variables para mov. del enemigo.
    public string playerTag = "Player"; // Etiqueta del jugador
    private Transform player;
    public float velocidad = 3.0f; // Velocidad de movimiento del enemigo.

    //Pantalla de derrota
    public GameObject pantalladerrota;

    // Start is called before the first frame update
    void Start()
    {
        // Buscar el objeto del jugador utilizando la etiqueta.
        player = GameObject.FindGameObjectWithTag(playerTag).transform;

        if (player == null)
        {
            Debug.LogError("No se encontró un objeto con la etiqueta: " + playerTag);
        }
    }

    // Update is called once per frame
    void Update()
    {
         if (player != null)
        {
            // Mover al enemigo hacia el jugador.
            Vector3 direccion = (player.position - transform.position).normalized;
            transform.position += direccion * velocidad * Time.deltaTime;

            // Comprobar si el enemigo ha alcanzado al jugador.
            if (Vector3.Distance(transform.position, player.position) < 1.0f)
            {
                // Eliminar al jugador.
                Destroy(player.gameObject);
                PantallaDerrota();
                Time.timeScale = 0; // Congela el juego.
            }
        }
    }

    private void PantallaDerrota()
    {
        pantalladerrota.SetActive(true); // Activa el objeto de fin de juego.
    }
}
