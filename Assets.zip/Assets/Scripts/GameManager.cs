using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public Collider antigavedad;
    public GameObject pantallafinal;
    public TextMeshProUGUI timerText;
    public int coleccionablesTotales;
    private int obtenidos = 0;
    private float startTime;
    private bool levelComplete = false;

    void Start()
    {
        startTime = Time.time;
        antigavedad = GetComponent<Collider>();
    }

    void Update()
    {
        if (levelComplete)
        {
            return;
        }

        if (obtenidos >= coleccionablesTotales)
        {
            levelComplete = true;
            PantallaFinal();
            Time.timeScale = 0; // Congela el juego.
        }

        // Actualiza el tiempo transcurrido en el TextMeshPro.
        float elapsedTime = Time.time - startTime;
        string minutes = ((int)elapsedTime / 60).ToString("00");
        string seconds = (elapsedTime % 60).ToString("00");
        timerText.text = "Tiempo: " + minutes + ":" + seconds;
    }

    public void CollectibleCollected()
    {
        obtenidos++;

        if (obtenidos >= coleccionablesTotales)
        {
            PantallaFinal();
        }

        if (obtenidos >= 3)
        {
            // Aquí asumiremos que "other" se refiere al GameObject que deseas destruir.
            // Para destruir un GameObject por etiqueta, se puede hacer así:
            GameObject[] garajes = GameObject.FindGameObjectsWithTag("Garaje");
            foreach (GameObject garaje in garajes)
            {
                Destroy(garaje);
            }
        }
    }

    void PantallaFinal()
    {
        pantallafinal.SetActive(true);
    }
}
